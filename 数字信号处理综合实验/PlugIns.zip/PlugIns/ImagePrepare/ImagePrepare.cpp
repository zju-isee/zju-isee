// ImagePrepare.cpp : Defines the initialization routines for the DLL.

#include "stdafx.h"
#include "ImagePrepare.h"
//
#include "BufStruct.h"
#include "ImageProc.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//
/////////////////////////////////////////////////////////////////////////////
// CImagePrepareApp
BEGIN_MESSAGE_MAP(CImagePrepareApp, CWinApp)
	//{{AFX_MSG_MAP(CImagePrepareApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//
/////////////////////////////////////////////////////////////////////////////
// CImagePrepareApp construction
CImagePrepareApp::CImagePrepareApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CImagePrepareApp object
CImagePrepareApp theApp;

char sInfo[] = "��������-����ͷ��Ƶ��ͼƬ��ȡ�������";
bool bLastPlugin = false;

DLL_EXP void ON_PLUGIN_BELAST(bool bLast)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());//ģ��״̬�л�
	bLastPlugin = bLast;
}
//�������
DLL_EXP LPCTSTR ON_PLUGININFO(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());//ģ��״̬�л�
	return sInfo;
}
//
DLL_EXP void ON_INITPLUGIN(LPVOID lpParameter)
{   
	AFX_MANAGE_STATE(AfxGetStaticModuleState());//ģ��״̬�л�
	//theApp.dlg.Create(IDD_PLUGIN_SETUP);
	//theApp.dlg.ShowWindow(SW_HIDE);
}
DLL_EXP int ON_PLUGINCTRL(int nMode,void* pParameter)
{
//ģ��״̬�л�
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	int nRet = 0;
	return nRet;
}
/*******************************************************************/
//��ͼƬ���Ƶ�Ŀ��ͼƬ�е�ĳһ����
/*******************************************************************/
DLL_EXP void CopyToRect(
	         aBYTE* ThisImage,//����ͼƬָ��
			 aBYTE* anImage,//Ŀ��ͼƬָ��
			 int W,int H,//����ͼƬ��С
		     int DestW,int DestH,//Ŀ��ͼƬ��С
			 int nvLeft,int nvTop,//����λ�ã�ͼƬ���Ͻ���Ŀ��ͼƬ������
			 bool bGray//�Ҷ�ͼƬ��ǣ�true���Ҷȣ�false����ɫ��
					  )
{
    aBYTE  * lpSrc = ThisImage;
    aBYTE  * lpDes = anImage;
    aBYTE  * lps, * lpd;
    int h;
	ASSERT(ThisImage && anImage);
    ASSERT( nvLeft+W<=DestW && nvTop+H<=DestH && nvLeft>=0 && nvTop>=0 );
	//Y
    for(h=0;h<H;h++){
        lpd = lpDes+(nvTop+h)*DestW+nvLeft;
        lps = lpSrc+(DWORD)h*W;
		memcpy(lpd,lps,W);
    }
	if( bGray )	return;
	//U
	lpSrc += W*H;
	lpDes += DestW*DestH;
    for(h=0;h<H;h++){
        lpd = lpDes+(nvTop+h)*(DestW/2)+nvLeft/2;
        lps = lpSrc+(DWORD)h*W/2;
		memcpy(lpd,lps,W/2);
    }
	//V
	lpSrc += W*H/2;
	lpDes += DestW*DestH/2;
    for(h=0;h<H;h++){
        lpd = lpDes+(nvTop+h)*(DestW/2)+nvLeft/2;
        lps = lpSrc+(DWORD)h*W/2;
		memcpy(lpd,lps,W/2);
    }
}
/****************************************************************************************/
/*                             ����ͷ��Ƶ��ͼƬ��ȡ���ز����ȴ���                       */
/****************************************************************************************/
DLL_EXP void ON_PLUGINRUN(int w,int h,BYTE* pYBits,BYTE* pUBits,BYTE* pVBits,BYTE* pBuffer)
{
//pYBits ��СΪw*h
//pUBits �� pVBits �Ĵ�СΪ w*h/2
//pBuffer �Ĵ�СΪ w*h*6
//�����㷨������һ�����裬��w��16�ı���
	AFX_MANAGE_STATE(AfxGetStaticModuleState());//ģ��״̬�л�
   
	//ShowDebugMessage("��printf�����÷�����,X=%d,Y=%d\n",10,5);

     //���д��Ӧ��������

	if (((BUF_STRUCT*)pBuffer)->bNotInited) {
		((BUF_STRUCT*)pBuffer)->colorBmp = pBuffer + sizeof(BUF_STRUCT);
		((BUF_STRUCT*)pBuffer)->grayBmp = ((BUF_STRUCT*)pBuffer)->colorBmp;
		((BUF_STRUCT*)pBuffer)->clrBmp_1d8 = ((BUF_STRUCT*)pBuffer)->grayBmp + w*h*2;
		((BUF_STRUCT*)pBuffer)->grayBmp_1d16 = ((BUF_STRUCT*)pBuffer)->clrBmp_1d8 + w*h/4;
		((BUF_STRUCT*)pBuffer)->TempImage1d8 = ((BUF_STRUCT*)pBuffer)->grayBmp_1d16 + w*h/16;
		((BUF_STRUCT*)pBuffer)->lastImageQueue1d16m8 = ((BUF_STRUCT*)pBuffer)->TempImage1d8 + w*h/8;
		((BUF_STRUCT*)pBuffer)->pOtherVars = (OTHER_VARS*)(((BUF_STRUCT*)pBuffer)->lastImageQueue1d16m8 + w*h/2);
		((BUF_STRUCT*)pBuffer)->pOtherData = (aBYTE*)((BUF_STRUCT*)pBuffer)->pOtherVars + sizeof(OTHER_VARS);
		for (int i = 0; i <= 7; i++)
			((BUF_STRUCT*)pBuffer)->pImageQueue[i] = ((BUF_STRUCT*)pBuffer)->lastImageQueue1d16m8 + i*(w*h/16);

		((BUF_STRUCT*)pBuffer)->W = w;
		((BUF_STRUCT*)pBuffer)->H = h;
		((BUF_STRUCT*)pBuffer)->cur_allocSize = 0;
		((BUF_STRUCT*)pBuffer)->allocTimes = 0;
		((BUF_STRUCT*)pBuffer)->cur_maxallocsize = 0;
		
		//ʡ����һЩ��ʱ�ò����ĳ�ʼ��

		((BUF_STRUCT*)pBuffer)->max_allocSize = w*h*17/16 - sizeof(BUF_STRUCT) - sizeof(OTHER_VARS);
		myHeapAllocInit((BUF_STRUCT*)pBuffer);
		((BUF_STRUCT*)pBuffer)->bNotInited = false;
	}
	
	((BUF_STRUCT*)pBuffer)->displayImage = pYBits;
	
	memcpy(((BUF_STRUCT*)pBuffer)->colorBmp, pYBits, w*h*2);
	
	ReSample(((BUF_STRUCT*)pBuffer)->colorBmp, w, h, w/2, h/4, false, false, ((BUF_STRUCT*)pBuffer)->clrBmp_1d8);
	ReSample(((BUF_STRUCT*)pBuffer)->grayBmp, w, h, w/4, h/4, false, true, ((BUF_STRUCT*)pBuffer)->grayBmp_1d16);

	//����Ĳ������ڲ���ͼ������Ľ���Ƿ���ȷ��
	
		if( bLastPlugin )
		{
		
			//����grayBmp_1d16:��grayBmp_1d16���Ƶ���ʾͼƬ�����Ͻ�
			CopyToRect(((BUF_STRUCT*)pBuffer)->grayBmp_1d16, pYBits, w/4, h/4, w, h, 0, 0, true);
			//����colorBmp:��clrBmp_1d8���Ƶ���ʾͼƬ�����Ͻ�
			CopyToRect(((BUF_STRUCT*)pBuffer)->clrBmp_1d8,  pYBits, w/2, h/4, w, h, w/2, 0, false);
		}
	
}



DLL_EXP void ON_PLUGINEXIT()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());//ģ��״̬�л�
	//theApp.dlg.DestroyWindow();
}
